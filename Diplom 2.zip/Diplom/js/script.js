/* ==========================================================
   SCROLL TO TOP ON RELOAD
========================================================== */

// отключаем восстановление позиции скролла браузером
if ("scrollRestoration" in window.history) {
    window.history.scrollRestoration = "manual";
}

// гарантированно в начало страницы при загрузке
window.addEventListener("load", () => {
    window.scrollTo(0, 0);
});


/* ==========================================================
   MOBILE MENU
========================================================== */

const burger = document.getElementById("burger");
const mobileMenu = document.getElementById("mobileMenu");

if (burger && mobileMenu) {
    burger.addEventListener("click", () => {
        mobileMenu.classList.toggle("active");
        burger.classList.toggle("burger-open");
    });
}


/* ==========================================================
   POPUPS
========================================================== */

const popups = document.querySelectorAll(".popup");
const openPopupLinks = document.querySelectorAll(".open-popup");
const closeButtons = document.querySelectorAll(".popup-close");

function openPopup(id) {
    popups.forEach(p => (p.style.display = "none"));
    const popup = document.querySelector(id);
    if (popup) popup.style.display = "flex";
}

function closeAllPopups() {
    popups.forEach(p => (p.style.display = "none"));
}

openPopupLinks.forEach(link => {
    link.addEventListener("click", e => {
        e.preventDefault();
        const target = link.getAttribute("href");
        openPopup(target);
    });
});

closeButtons.forEach(btn => {
    btn.addEventListener("click", () => closeAllPopups());
});

popups.forEach(popup => {
    popup.addEventListener("click", e => {
        if (e.target === popup) closeAllPopups();
    });
});


/* ==========================================================
   LOGIN BUTTON (в шапке)
========================================================== */

const loginBtnHeader = document.querySelector("header .btn-orange.open-popup");
if (loginBtnHeader) {
    loginBtnHeader.addEventListener("click", (e) => {
        e.preventDefault();
        openPopup("#popup-login");
    });
}


/* ==========================================================
   TRIAL FORM → SUCCESS POPUP
========================================================== */

const trialForm = document.querySelector(".trial-form");
if (trialForm) {
    trialForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const fields = trialForm.querySelectorAll("input, select");
        for (let f of fields) {
            if (!f.value.trim()) return;
        }

        openPopup("#popup-success");
        trialForm.reset();
    });
}


/* ==========================================================
   SWIPER GALLERY
========================================================== */

const gallerySwiper = new Swiper('.gallery-slider', {
    loop: true,
    speed: 1200,
    spaceBetween: 24,
    slidesPerView: 3,
    centeredSlides: false,

    autoplay: {
        delay: 2600,
        disableOnInteraction: false,
    },

    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },

    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev'
    },

    breakpoints: {
        0:   { slidesPerView: 1 },
        700: { slidesPerView: 2 },
        1024:{ slidesPerView: 3 }
    }
});

/* — Автозапуск только когда видно секцию — */
const gallerySection = document.querySelector(".gallery");

if (gallerySection) {
    const galleryObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) gallerySwiper.autoplay.start();
            else gallerySwiper.autoplay.stop();
        });
    }, { threshold: 0.35 });

    galleryObserver.observe(gallerySection);
}


/* ==========================================================
   SCROLL ANIMATIONS
========================================================== */

const scrollElements = document.querySelectorAll(
    ".fade-up, .fade-left, .fade-right, .scale-in, .direction-card, .adv-card, .price-card"
);

function elementInView(el, offset = 120) {
    return el.getBoundingClientRect().top <= (window.innerHeight - offset);
}

function handleScrollAnimation() {
    scrollElements.forEach(el => {
        if (elementInView(el)) {
            el.classList.add("visible");
        }
    });
}

window.addEventListener("scroll", handleScrollAnimation);
window.addEventListener("load", handleScrollAnimation);
handleScrollAnimation();


/* ==========================================================
   LOGO SCROLL TO TOP
========================================================== */

const scrollTopBtn = document.getElementById("scrollTopBtn");

if (scrollTopBtn) {
    scrollTopBtn.addEventListener("click", e => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}


/* ==========================================================
   CURSOR TRAIL (🔥 ОГНЕННЫЙ ХВОСТ)
========================================================== */

document.addEventListener("mousemove", (e) => {
    const trail = document.createElement("div");
    trail.className = "trail";

    trail.style.left = `${e.clientX}px`;
    trail.style.top = `${e.clientY}px`;

    document.body.appendChild(trail);

    setTimeout(() => { trail.remove(); }, 400);
});


/* ==========================================================
   SAFARI FIXES (дублирование observer анимаций)
========================================================== */
window.addEventListener("pageshow", () => {
    scrollElements.forEach(el => {
        if (elementInView(el)) el.classList.add("visible");
    });
});



