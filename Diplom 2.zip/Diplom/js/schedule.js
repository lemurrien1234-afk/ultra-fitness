/* ==========================================================
   SCHEDULE SYSTEM (улучшено + кликабельные тренеры)
========================================================== */

/* ---- ДАННЫЕ ---- */

const scheduleData = [
    /* ================= ПОНЕДЕЛЬНИК ================= */
    { time: "08:00", name: "Йога",                 trainer: "Гордеева А.",  trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Понедельник" },
    { time: "09:00", name: "Кардио Mix",           trainer: "Ковалёв А.",   trainerId: 2, hall: "Зал 3", type: "Кардио", day: "Понедельник" },
    { time: "10:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Понедельник" },
    { time: "11:00", name: "Групповая тренировка", trainer: "Смирнова Е.",  trainerId: 4, hall: "Зал 1", type: "Групповая тренировка", day: "Понедельник" },
    { time: "12:00", name: "Пилатес",              trainer: "Гордеева А.",  trainerId: 1, hall: "Зал 2", type: "Стретчинг", day: "Понедельник" },
    { time: "14:00", name: "Тренажёрный зал",      trainer: "Сергеев Д.",   trainerId: 5, hall: "Зал 5", type: "Тренажерный зал", day: "Понедельник" },
    { time: "16:00", name: "Бокс",                 trainer: "Морозов П.",   trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Понедельник" },
    { time: "18:00", name: "HIIT",                 trainer: "Ковалёв А.",   trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Понедельник" },
    { time: "19:00", name: "Кардио-интервалы",     trainer: "Иванов И.",    trainerId: 3, hall: "Зал 3", type: "Кардио", day: "Понедельник" },
    { time: "20:00", name: "Растяжка",             trainer: "Смирнова Е.",  trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Понедельник" },

    /* ================= ВТОРНИК ================= */
    { time: "08:00", name: "Кардио Заряд",        trainer: "Гордеева А.",  trainerId: 1, hall: "Зал 3", type: "Кардио", day: "Вторник" },
    { time: "09:00", name: "Йога",                trainer: "Смирнова Е.",  trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Вторник" },
    { time: "10:00", name: "Групповая тренировка", trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 2", type: "Групповая тренировка", day: "Вторник" },
    { time: "12:00", name: "Тренажёрный зал",     trainer: "Сергеев Д.",   trainerId: 5, hall: "Зал 5", type: "Тренажерный зал", day: "Вторник" },
    { time: "14:00", name: "ММА",                 trainer: "Морозов П.",   trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Вторник" },
    { time: "16:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Вторник" },
    { time: "17:00", name: "HIIT",                trainer: "Ковалёв А.",   trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Вторник" },
    { time: "18:00", name: "Пилатес",             trainer: "Гордеева А.",  trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Вторник" },
    { time: "19:00", name: "Бокс",                trainer: "Морозов П.",   trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Вторник" },
    { time: "20:00", name: "Кардио Mix",          trainer: "Иванов И.",    trainerId: 3, hall: "Зал 3", type: "Кардио", day: "Вторник" },

    /* ================= СРЕДА ================= */
    { time: "08:00", name: "Пилатес",             trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Среда" },
    { time: "09:00", name: "HIIT",                trainer: "Ковалёв А.",  trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Среда" },
    { time: "10:00", name: "Групповая тренировка", trainer: "Гордеева А.", trainerId: 1, hall: "Зал 2", type: "Групповая тренировка", day: "Среда" },
    { time: "12:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Среда" },
    { time: "14:00", name: "Бокс",               trainer: "Морозов П.",  trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Среда" },
    { time: "16:00", name: "Тренажёрный зал",    trainer: "Сергеев Д.",  trainerId: 5, hall: "Зал 5", type: "Тренажерный зал", day: "Среда" },
    { time: "18:00", name: "Йога",               trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Среда" },
    { time: "19:00", name: "HIIT",               trainer: "Ковалёв А.",  trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Среда" },
    { time: "20:00", name: "Кардио-интервалы",   trainer: "Иванов И.",   trainerId: 3, hall: "Зал 3", type: "Кардио", day: "Среда" },

    /* ================= ЧЕТВЕРГ ================= */
    { time: "08:00", name: "Йога",               trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Четверг" },
    { time: "09:00", name: "Кардио Mix",         trainer: "Ковалёв А.",  trainerId: 2, hall: "Зал 3", type: "Кардио", day: "Четверг" },
    { time: "10:00", name: "Групповая тренировка", trainer: "Гордеева А.", trainerId: 1, hall: "Зал 2", type: "Групповая тренировка", day: "Четверг" },
    { time: "12:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Четверг" },
    { time: "14:00", name: "Бокс",               trainer: "Морозов П.",  trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Четверг" },
    { time: "16:00", name: "HIIT",               trainer: "Ковалёв А.",  trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Четверг" },
    { time: "18:00", name: "Пилатес",            trainer: "Гордеева А.", trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Четверг" },
    { time: "19:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Четверг" },
    { time: "20:00", name: "Кардио",             trainer: "Ковалёв А.",  trainerId: 2, hall: "Зал 3", type: "Кардио", day: "Четверг" },

    /* ================= ПЯТНИЦА ================= */
    { time: "08:00", name: "Пилатес",            trainer: "Гордеева А.", trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Пятница" },
    { time: "09:00", name: "Йога",               trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Пятница" },
    { time: "10:00", name: "Тренажёрный зал",    trainer: "Сергеев Д.",  trainerId: 5, hall: "Зал 5", type: "Тренажерный зал", day: "Пятница" },
    { time: "12:00", name: "ММА",                trainer: "Морозов П.",  trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Пятница" },
    { time: "14:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Пятница" },
    { time: "16:00", name: "HIIT",               trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Пятница" },
    { time: "18:00", name: "Кардио Mix",         trainer: "Иванов И.", trainerId: 3, hall: "Зал 3", type: "Кардио", day: "Пятница" },
    { time: "19:00", name: "Растяжка",           trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Пятница" },

    /* ================= СУББОТА ================= */
    { time: "09:00", name: "Йога выходного дня", trainer: "Гордеева А.", trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Суббота" },
    { time: "10:00", name: "Кардио",             trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 3", type: "Кардио", day: "Суббота" },
    { time: "12:00", name: "Групповая тренировка", trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 2", type: "Групповая тренировка", day: "Суббота" },
    { time: "14:00", name: "Бокс",               trainer: "Морозов П.", trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Суббота" },
    { time: "16:00", name: "HIIT",               trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Суббота" },
    { time: "18:00", name: "Пилатес",            trainer: "Гордеева А.", trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Суббота" },

    /* ================= ВОСКРЕСЕНЬЕ ================= */
    { time: "10:00", name: "Йога Relax",         trainer: "Смирнова Е.", trainerId: 4, hall: "Зал 1", type: "Стретчинг", day: "Воскресенье" },
    { time: "11:00", name: "Кардио-интервалы",   trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 3", type: "Кардио", day: "Воскресенье" },
    { time: "13:00", name: "Функциональный тренинг", trainer: "Иванов И.", trainerId: 3, hall: "Зал 2", type: "Функциональный тренинг", day: "Воскресенье" },
    { time: "15:00", name: "ММА",                trainer: "Морозов П.", trainerId: 6, hall: "Зал 4", type: "Единоборства", day: "Воскресенье" },
    { time: "17:00", name: "Пилатес",            trainer: "Гордеева А.", trainerId: 1, hall: "Зал 1", type: "Стретчинг", day: "Воскресенье" },
    { time: "19:00", name: "HIIT Вечерний",      trainer: "Ковалёв А.", trainerId: 2, hall: "Зал 3", type: "HIIT", day: "Воскресенье" }
];

/* ---- ЭЛЕМЕНТЫ ---- */
const scheduleBody   = document.getElementById("schedule-body");
const filterType     = document.getElementById("filter-type");
const filterTrainer  = document.getElementById("filter-trainer");
const filterDay      = document.getElementById("filter-day");
const dayButtons     = document.querySelectorAll(".day-btn");

let selectedDay = "Понедельник";


/* ==========================================================
   РЕНДЕР РАСПИСАНИЯ
========================================================== */
function renderSchedule() {
    if (!scheduleBody) return;

    scheduleBody.innerHTML = "";

    const filtered = scheduleData.filter(item => (
        (filterType.value   === "" || filterType.value   === item.type) &&
        (filterTrainer.value=== "" || filterTrainer.value=== item.trainer) &&
        (filterDay.value    === "" || filterDay.value    === item.day) &&
        (selectedDay === "all" || item.day === selectedDay)
    ));

    if (filtered.length === 0) {
        scheduleBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; color: #777; padding: 18px;">
                    Нет тренировок по выбранным фильтрам
                </td>
            </tr>
        `;
        return;
    }

    filtered.forEach(item => {
        scheduleBody.innerHTML += `
        <tr>
            <td>${item.time}</td>
            <td>${item.name}</td>
            
            <!-- ИМЯ ТРЕНЕРА → КЛИКАБЕЛЬНОЕ -->
            <td>
                <a href="trainer-profile.html?id=${item.trainerId}" class="trainer-link">
                    ${item.trainer}
                </a>
            </td>

            <td>${item.hall}</td>

            <td>
                <button class="btn-orange sign-btn" data-name="${item.name}">
                    Записаться
                </button>
            </td>
        </tr>`;
    });

    document.querySelectorAll(".sign-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const titleEl = document.getElementById("popup-training-name");
            if (titleEl) {
                titleEl.innerText = btn.dataset.name;
            }
            if (typeof openPopup === "function") {
                openPopup("#popup-sign");
            }
        });
    });
}


/* ==========================================================
   МИНИ-КАЛЕНДАРЬ (кнопки дней)
========================================================== */

dayButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        dayButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        selectedDay = btn.dataset.day;

        if (filterDay) {
            filterDay.value = (selectedDay === "all") ? "" : selectedDay;
        }

        renderSchedule();
    });
});


/* ==========================================================
   SELECT "День недели"
========================================================== */

if (filterDay) {
    filterDay.addEventListener("change", () => {
        selectedDay = filterDay.value || "all";

        dayButtons.forEach(btn => {
            const active =
                (selectedDay === "all" && btn.dataset.day === "all") ||
                (btn.dataset.day === selectedDay);
            btn.classList.toggle("active", active);
        });

        renderSchedule();
    });
}


/* ==========================================================
   ФИЛЬТРЫ ТИПА И ТРЕНЕРА
========================================================== */

filterType?.addEventListener("change", renderSchedule);
filterTrainer?.addEventListener("change", renderSchedule);


/* ==========================================================
   ПЕРВЫЙ ЗАПУСК
========================================================== */
renderSchedule();
