/* ==========================================================
   ВСЁ ДЕЛАЕМ ПОСЛЕ ЗАГРУЗКИ DOM
========================================================== */
document.addEventListener("DOMContentLoaded", () => {

    /* ==========================================================
       MOBILE MENU
    ========================================================== */

    const burger = document.getElementById("burger");
    const mobileMenu = document.getElementById("mobileMenu");

    if (burger && mobileMenu) {
        burger.addEventListener("click", () => {
            mobileMenu.classList.toggle("active");
            burger.classList.toggle("burger-open");
        });
    }


    /* ==========================================================
       POPUPS
    ========================================================== */

    const popups = document.querySelectorAll(".popup");
    const openPopupLinks = document.querySelectorAll(".open-popup");
    const closeButtons = document.querySelectorAll(".popup-close");

    function lockScroll() {
        document.body.style.overflow = "hidden";
    }

    function unlockScroll() {
        document.body.style.overflow = "";
    }

    function openPopup(id) {
        // сначала закрываем все попапы
        popups.forEach(p => {
            p.style.display = "none";
            p.classList.remove("popup-visible");
        });

        const popup = document.querySelector(id);
        if (popup) {
            popup.style.display = "flex";
            popup.classList.add("popup-visible");
            lockScroll();
        }
    }

    function closeAllPopups() {
        popups.forEach(p => {
            p.style.display = "none";
            p.classList.remove("popup-visible");
        });
        unlockScroll();
    }

    // клики по ссылкам/кнопкам с .open-popup
    openPopupLinks.forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();
            const target = link.getAttribute("href");
            if (target && target.startsWith("#")) {
                openPopup(target);
            }
        });
    });

    // кнопки закрытия с классом .popup-close
    closeButtons.forEach(btn => {
        btn.addEventListener("click", () => closeAllPopups());
    });

    // клик по фону попапа
    popups.forEach(popup => {
        popup.addEventListener("click", e => {
            if (e.target === popup) closeAllPopups();
        });
    });

    // ESC закрывает попап
    document.addEventListener("keydown", e => {
        if (e.key === "Escape") closeAllPopups();
    });


    /* ==========================================================
       LOGO → SCROLL TO TOP
    ========================================================== */

    const scrollTopBtn = document.getElementById("scrollTopBtn");
    if (scrollTopBtn) {
        scrollTopBtn.addEventListener("click", e => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }


    /* ==========================================================
       TRIAL FORM → SUCCESS POPUP
    ========================================================== */

    const trialForm = document.querySelector(".trial-form");
    if (trialForm) {
        trialForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const fields = trialForm.querySelectorAll("input, select");
            for (let f of fields) {
                if (!f.value.trim()) return;
            }

            openPopup("#popup-success");
            trialForm.reset();
        });
    }


    /* ==========================================================
       SCROLL ANIMATIONS
    ========================================================== */

    const scrollElements = document.querySelectorAll(
        ".fade-up, .fade-left, .fade-right, .scale-in, .direction-card, .adv-card, .price-card"
    );

    function elementInView(el, offset = 120) {
        return el.getBoundingClientRect().top <= (window.innerHeight - offset);
    }

    function handleScrollAnimation() {
        scrollElements.forEach(el => {
            if (elementInView(el)) el.classList.add("visible");
        });
    }

    window.addEventListener("scroll", handleScrollAnimation);
    window.addEventListener("load", handleScrollAnimation);


    /* ==========================================================
       CURSOR TRAIL
    ========================================================== */

    document.addEventListener("mousemove", (e) => {
        const trail = document.createElement("div");
        trail.className = "trail";

        trail.style.left = `${e.clientX}px`;
        trail.style.top = `${e.clientY}px`;

        document.body.appendChild(trail);

        setTimeout(() => { trail.remove(); }, 400);
    });


    /* ==========================================================
       PHONE MASK (+7 (___) ___-__-__)
    ========================================================== */

    document.querySelectorAll('input[type="tel"]').forEach(input => {
        input.addEventListener("input", maskPhone);
        input.addEventListener("focus", maskPhone);
        input.addEventListener("blur", maskPhone);
    });

    function maskPhone(e) {
        let value = e.target.value.replace(/\D/g, "");
        if (!value.startsWith("7")) value = "7" + value;

        let result = "+7";

        if (value.length > 1) result += " (" + value.substring(1, 4);
        if (value.length >= 5) result += ") " + value.substring(4, 7);
        if (value.length >= 8) result += "-" + value.substring(7, 9);
        if (value.length >= 10) result += "-" + value.substring(9, 11);

        e.target.value = result;
    }

});
/* ==========================================================
   CSS ДЛЯ ПЛАВНОГО ПОЯВЛЕНИЯ ПОПАПА (ДОБАВЬ В style.css)
========================================================== */
/*
.popup {
    opacity: 0;
    transition: opacity .3s ease;
}

.popup-visible {
    opacity: 1 !important;
}
*/
