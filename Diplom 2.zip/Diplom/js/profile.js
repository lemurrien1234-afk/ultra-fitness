/* ==========================================================
   Загрузка сохранённых данных при входе
========================================================== */

let userData = JSON.parse(localStorage.getItem("userData")) || {
    role: "user",
    name: "",
    age: "",
    height: "",
    weight: "",
    goal: "",
    progressPhotos: [],
    weightHistory: []
};

/* ==========================================================
   ВКЛАДКИ
========================================================== */

const tabButtons = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");

tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        // Активная кнопка
        tabButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        // Открыть выбранный таб
        const target = btn.dataset.tab;
        tabContents.forEach(tc => {
            tc.classList.toggle("active", tc.id === `tab-${target}`);
        });
    });
});

/* ==========================================================
   АВАТАРКА
========================================================== */

const photoInput = document.getElementById("photoInput");
const profilePhoto = document.getElementById("profilePhoto");

photoInput?.addEventListener("change", () => {
    const file = photoInput.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
        profilePhoto.src = reader.result;
        userData.avatar = reader.result;
        saveUserData();
    };
    reader.readAsDataURL(file);
});

/* ==========================================================
   ЗАПОЛНЕНИЕ ПОЛЕЙ ЕСЛИ ДАННЫЕ ЕСТЬ
========================================================== */

function loadProfileToForm() {
    if (userData.avatar) profilePhoto.src = userData.avatar;
    if (userData.name) userName.value = userData.name;
    if (userData.age) userAge.value = userData.age;
    if (userData.height) userHeight.value = userData.height;
    if (userData.weight) userWeight.value = userData.weight;
    if (userData.goal) userGoal.value = userData.goal;
}
loadProfileToForm();

/* ==========================================================
   СОХРАНЕНИЕ ПРОФИЛЯ
========================================================== */

document.getElementById("saveProfile")?.addEventListener("click", () => {
    userData.name = userName.value;
    userData.age = userAge.value;
    userData.height = userHeight.value;
    userData.weight = userWeight.value;
    userData.goal = userGoal.value;

    // Добавляем запись в историю веса
    if (userWeight.value) {
        userData.weightHistory.push({
            date: new Date().toLocaleDateString(),
            weight: Number(userWeight.value)
        });
    }

    saveUserData();

    alert("Данные сохранены!");
});

/* ==========================================================
   ФУНКЦИЯ СОХРАНЕНИЯ
========================================================== */

function saveUserData() {
    localStorage.setItem("userData", JSON.stringify(userData));
}

/* ==========================================================
   ПРОГРЕСС — ГРАФИК ВЕСА
========================================================== */

let chart;

function renderWeightChart() {
    const ctx = document.getElementById("weightChart");
    if (!ctx) return;

    if (chart) chart.destroy();

    const labels = userData.weightHistory.map(i => i.date);
    const values = userData.weightHistory.map(i => i.weight);

    chart = new Chart(ctx, {
        type: "line",
        data: {
            labels,
            datasets: [{
                label: "Вес (кг)",
                data: values,
                borderColor: "#ff7a00",
                backgroundColor: "rgba(255,122,0,0.25)",
                borderWidth: 3,
                pointRadius: 5,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                x: { ticks: { color: "#ccc" } },
                y: { ticks: { color: "#ccc" } }
            },
            plugins: {
                legend: { labels: { color: "#eee" } }
            }
        }
    });
}

renderWeightChart();

/* ==========================================================
   ДОБАВЛЕНИЕ ФОТО ПРОГРЕССА
========================================================== */

const progressPhotosBlock = document.getElementById("progressPhotos");
const progressPhotoInput = document.getElementById("progressPhotoInput");

progressPhotoInput?.addEventListener("change", () => {
    const file = progressPhotoInput.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
        userData.progressPhotos.push(reader.result);
        saveUserData();
        renderProgressPhotos();
    };
    reader.readAsDataURL(file);
});

function renderProgressPhotos() {
    if (!progressPhotosBlock) return;
    progressPhotosBlock.innerHTML = "";

    userData.progressPhotos.forEach(photo => {
        const img = document.createElement("img");
        img.src = photo;
        progressPhotosBlock.appendChild(img);
    });
}

renderProgressPhotos();

/* ==========================================================
   ТРЕНЕРСКИЙ РЕЖИМ (пароль: trener1234)
========================================================== */

function detectTrainerRole() {
    if (userData.role === "trainer") {
        document.getElementById("trainerTab").style.display = "inline-block";
    }
}
detectTrainerRole();

/* ==========================================================
   ИМИТАЦИЯ СПИСКА УЧЕНИКОВ ТРЕНЕРА
========================================================== */

const trainerStudentsList = document.getElementById("trainerStudentsList");

if (trainerStudentsList) {
    const demoStudents = [
        "Марина К.",
        "Артём Б.",
        "Данил С.",
        "Екатерина Л.",
        "Илья П."
    ];

    trainerStudentsList.innerHTML = demoStudents
        .map(s => `<li>${s}</li>`)
        .join("");
}
